# dotlocalctl

A simple tool to manage local DNS records.
